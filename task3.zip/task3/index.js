


window.onscroll = function(){
let w =window.scrollY;
console.log(w);

if(document.documentElement.scrollTop>100){
     document.getElementById("head").classList.add("nextheader");

}else{

    document.getElementById("head").classList.remove("nextheader");
}

}




setTimeout(function(){

    document.getElementById("box").style.display="block"
       
    
    },5000)

    
    setTimeout(function(){

        document.getElementById("box").style.display="none"
           
        
        },10000)


       let show=document.getElementById("btn");

       show.onmouseover=function(){

        document.getElementById("side").style.display="block"
       }


       show.onmouseout=function(){

        document.getElementById("side").style.display="none"
       }